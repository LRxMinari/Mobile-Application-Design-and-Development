import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { FontAwesome5 } from '@expo/vector-icons';

import HomeScreen from './src/screens/HomeScreen';
import ListScreen from './src/screens/ListScreen';
import { AntDesign } from '@expo/vector-icons';

const Stack = createNativeStackNavigator()
const Tab = createBottomTabNavigator();

const HomeStackScreen = () => {
  return (
    <Stack.Navigator>
      <Stack.Screen name="Home" component={HomeScreen}/>
      <Stack.Screen name="Second App" component={ListScreen}/>
    </Stack.Navigator>
  );
};

const App = ({num}) =>{
  return(
    <NavigationContainer>
      <Tab.Navigator
        screenOptions={{
          tabBarStyle: { backgroundColor: '#ddd' },
          tabBarActiveTintColor: '#F0B86E',
          headerStyle: { backgroundColor: '#ffa000' },
          headerTintColor: '#fff',
          headerShown: false,
        }}
      >
        <Tab.Screen
          name="HomeStack"
          component={HomeStackScreen}
          options={{
            tabBarIcon: ({ color, size }) => (
              <FontAwesome5
                name="home"
                size={size}
                color={color}
              ></FontAwesome5>
            ),
          }}
        />
        <Tab.Screen
          name="Search"
          component={ListScreen}
          options={{
            tabBarIcon: ({ color, size }) => (
              <AntDesign name="search1" size={24} color="black" />
            ),tabBarBadge: 14,
          }}
        />
      </Tab.Navigator>
    </NavigationContainer>


  );
};

export default App;