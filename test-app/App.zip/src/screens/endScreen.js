import { View,StyleSheet,FlatList } from "react-native";
import data from "..//data/data-001.json"
import RenderItem from "../componant/RenderItem";
const endScreen =({navigation}) =>{
    return(
        <View style={styles.container}>
            <FlatList
                data={Student}
                keyExtractor={(item) => item.id}
                renderItem={({ item }) => <RenderItem item={item}/>}
            />
        </View>
    );
};

const styles =StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#B7BF99',
        alignItems: 'center',
        justifyContent: 'center',
    },
});

export default endScreen;