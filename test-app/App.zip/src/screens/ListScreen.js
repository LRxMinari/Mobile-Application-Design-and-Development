import { View, Text, StyleSheet, Alert,Pressable,Image } from "react-native";
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { useState } from "react";
import MyButton from "../componant/MyButton";
import MyInput from "../componant/MyInput";
import data from "..//data/data-001.json"

const ListScreen = ({ navigation }) => {
return(
    <View style={styles.container}>
            <View style={styles.image}>
                <Image 
                    source={{uri: 'https://images.unsplash.com/photo-1533777324565-a040eb52facd?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&w=1000&q=80'}}
                    style = {{width: 150,height: 150,borderRadius: 100,borderColor: '#000000',borderWidth: 4}}
                />
            </View>
            <Text style={styles.text}>Pradipat Nantasarn</Text>
            <Text style={styles.text2}>6421600115</Text>
            <View style={styles.image}>
                <Image 
                    source={{uri: 'https://i.pinimg.com/originals/37/87/80/3787808639805ba94d055024457a4d7b.jpg'}}
                    style = {{width: 150,height: 150,borderRadius: 100,borderColor: '#000000',borderWidth: 4}}
                />
            </View>
            <Text style={styles.text}>Hi I am Winter❄️</Text>
            <Text style={styles.text2}>Aespa🎶</Text>
            <MyButton title="Let's get started" onPress={() => navigation.navigate("Search")}/>
        </View>
 );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#ffecb3',
        alignItems: 'center',
        justifyContent: 'center',
    },
    title: { fontSize: 20, fontWeight: 'bold' },

    text: { color: '#000000', fontSize: 20,fontWeight: 'bold', padding: 2 },
    text2: { color: '#757575', fontSize: 15, padding: 2 },


    image: {
        width: '100',
        height: '100',
        padding: 5
    }
});
export default ListScreen;