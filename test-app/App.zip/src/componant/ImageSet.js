import { View, Text, StyleSheet, TextInput } from "react-native";

const ImageSet = () =>{
    return(
        <ImageSet>
            <View style={styles.image}>
                <Image 
                    source={require('../img/Winter01.jpg')}
                    style = {{width: 150,height: 150,borderRadius: 100}}
                />
            </View>
            <Text style={styles.text}>Pradipat Nantasarn</Text>
            <Text style={styles.text2}>6421600115</Text>
            <View style={styles.image}>
            {
                <Image 
                    source={{uri: 'https://i.pinimg.com/originals/37/87/80/3787808639805ba94d055024457a4d7b.jpg'}}
                    style = {{width: 150,height: 150,borderRadius: 100}}
                /> }
                </View>
            <Text style={styles.text}>Hi I am Winter❄️</Text>
            <Text style={styles.text2}>Aespa🎶</Text>
        </ImageSet>
    )    
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#ffecb3',
        alignItems: 'center',
        justifyContent: 'center',
    },
    title: { fontSize: 20, fontWeight: 'bold' },

    text: { color: '#000000', fontSize: 20,fontWeight: 'bold', padding: 2 },
    text2: { color: '#757575', fontSize: 15, padding: 2 },


    image: {
        width: '100',
        height: '100',
        padding: 5
    }
});

export default ImageSet;
